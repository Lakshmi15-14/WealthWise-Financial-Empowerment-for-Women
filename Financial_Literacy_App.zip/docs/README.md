
# Financial Literacy App - HerWealth

## Project Overview
HerWealth is a financial empowerment app for women, providing budgeting, investment tracking, and financial education.

## Tech Stack
- **Frontend:** React Native
- **Backend:** Node.js with Express
- **Database:** MongoDB

## Features
- Financial education modules
- Budgeting tools & expense tracker
- Investment tracking & goal setting
- Community & mentorship

## Installation
1. Navigate to `frontend` and run `npm install`
2. Navigate to `backend` and run `npm install`
3. Start the backend server using `node server.js`
